package controller;

public class ExternalServicesProxy implements ExternalServices {

    private ExternalServicesFacade realServices;
    private boolean pearlAvailable = true;
    private boolean financeAvailable = true;

    public ExternalServicesProxy() {
        // lazy: don't create facade until needed
    }

    private ExternalServicesFacade getRealServices() {
        if (realServices == null) {
            realServices = new ExternalServicesFacade();
        }
        return realServices;
    }

    public void setPearlAvailable(boolean available) {
        this.pearlAvailable = available;
    }

    public void setFinanceAvailable(boolean available) {
        this.financeAvailable = available;
    }

    @Override
    public boolean verifyMember(String name) {
        System.out.println("[Proxy] Request to verify member: " + name);

        if (!pearlAvailable) {
            System.out.println("[Proxy] PearlSys is currently unavailable.");
            return false;
        }

        return getRealServices().verifyMember(name);
    }

    @Override
    public boolean transferDeposit(String financeAccountNo, double amount) {
        System.out.println("[Proxy] Request to transfer deposit: " + amount + " from " + financeAccountNo);

        if (!financeAvailable) {
            System.out.println("[Proxy] FinanceSys is currently unavailable.");
            return false;
        }

        return getRealServices().transferDeposit(financeAccountNo, amount);
    }
}
