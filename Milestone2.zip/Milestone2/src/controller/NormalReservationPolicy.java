package controller;

import java.util.List;

import model.Item;
import model.Member;
import model.Reservation;

/**
 * Basic reservation rules:
 *  - A member can have up to 5 active reservations.
 *  - An item cannot be reserved if it is already reserved.
 */
public class NormalReservationPolicy implements ReservationPolicy {

    private static final int MAX_RESERVATIONS = 5;

    @Override
    public ReservationResult canReserve(Member member, Item item, List<Reservation> reservations) {

        // Check how many items the member already reserved
        if (member.getTotalReservedItems() >= MAX_RESERVATIONS) {
            return ReservationResult.MEMBER_MAX_REACHED;
        }

        // Check if the item is already taken
        if (item.isReserved()) {
            return ReservationResult.ITEM_ALREADY_RESERVED;
        }

        return ReservationResult.OK;
    }
}
