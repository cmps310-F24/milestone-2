package controller;

public class ExternalServicesFacade implements ExternalServices {

    // In a real system these would be separate classes PearlSysClient, FinanceSysClient, etc.
    // Here we just simulate them.

    @Override
    public boolean verifyMember(String name) {
        // Simulate a call to PearlSys
        System.out.println("[PearlSys] Verifying member: " + name);

        // Simple example: any non-empty name is accepted
        return name != null && !name.trim().isEmpty();
    }

    @Override
    public boolean transferDeposit(String financeAccountNo, double amount) {
        // Simulate a call to FinanceSys
        System.out.println("[FinanceSys] Transferring " + amount + " from account " + financeAccountNo);

        // Simple rule: transfer succeeds if amount > 0
        return amount > 0;
    }
}
