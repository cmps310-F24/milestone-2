package controller;

/**
 * Result of applying a reservation policy
 * to check if a member can reserve an item.
 */
public enum ReservationResult {
    OK,
    MEMBER_MAX_REACHED,
    ITEM_ALREADY_RESERVED
}
