package controller;

public enum ReservationResult {
    OK,
    MEMBER_MAX_REACHED,
    ITEM_ALREADY_RESERVED
}
