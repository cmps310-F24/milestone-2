package controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Item;
import model.Member;
import model.MembershipApplication;
import model.Reservation;

public class LibrarySystem {

    // In-memory storage
    private Map<String, Member> members = new HashMap<>();
    private Map<String, Item> items = new HashMap<>();
    private List<Reservation> reservations = new ArrayList<>();

    // External services are accessed via Proxy (which wraps the Facade)
    private ExternalServices externalServices = new ExternalServicesProxy();

    // Strategy for reservation rules
    private ReservationPolicy reservationPolicy = new NormalReservationPolicy();

    private int memberSequence = 1000;
    private int financeSequence = 5000;

    public LibrarySystem() {
        loadInitialItems();
    }

    // Initial items (catalogue)
    private void loadInitialItems() {
        items.put("100001", new Item("100001", "CMPS 310", 2008));
        items.put("100002", new Item("100002", "CMPS 251", 1994));
        items.put("100003", new Item("100003", "CMPS 151", 2024));
        items.put("100004", new Item("100004", "CMPS 301", 2025));
        items.put("100005", new Item("100005", "CMPS 384", 2021));
        items.put("100006", new Item("100006", "CMPS 402", 2023));
    }


    // Register new member (Use Case 1)
    public String registerNewMember(String name, String address) {

        MembershipApplication app = new MembershipApplication(name, address, null);
        app.setAdminComments("Checked by admin staff.");

        boolean verified = externalServices.verifyMember(name);
        if (!verified) {
            app.setStatus("Rejected");
            return "Application rejected: verification failed.";
        }

        app.setStatus("TentativelyAccepted");

        String financeAccountNo = "FA" + (++financeSequence);
        app.setFinanceAccountNo(financeAccountNo);

        boolean transferOk = externalServices.transferDeposit(financeAccountNo, 1500.0);
        if (!transferOk) {
            return "Payment failed: FinanceSys did not transfer the required amount.";
        }

        String membershipNo = "M" + (++memberSequence);
        Member member = new Member(membershipNo, name, address, name, financeAccountNo);
        members.put(membershipNo, member);

        return "Membership created successfully.\n"
             + "Membership No: " + membershipNo + "\n"
             + "Finance Account No: " + financeAccountNo;
    }


    // Reserve item (Use Case 2)
    public String reserveItem(String membershipNo, String callNo) {

        Member member = members.get(membershipNo);
        if (member == null || !member.isActive()) {
            return "Reservation failed: Member account is not active or does not exist.";
        }

        Item item = items.get(callNo);
        if (item == null) {
            return "Reservation failed: Item does not exist in the system.";
        }

        ReservationResult result = reservationPolicy.canReserve(member, item, reservations);

        if (result == ReservationResult.MEMBER_MAX_REACHED) {
            return "Reservation failed: Member has reached the maximum number of reservations.";
        }

        if (result == ReservationResult.ITEM_ALREADY_RESERVED) {
            return "Reservation failed: The item is already reserved by another member.";
        }

        item.setReserved(true);
        member.increaseReservedItems();
        reservations.add(new Reservation(member, item));

        return "Reservation successful for member " + membershipNo
             + " on item " + callNo + ".";
    }


    // Getters
    public Map<String, Member> getMembers() {
        return members;
    }

    public Map<String, Item> getItems() {
        return items;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }


    // Available items list
    public String listAvailableItems() {

        String result = "Available Items:\n";
        result += "------------------------------\n";

        boolean any = false;

        for (Map.Entry<String, Item> entry : items.entrySet()) {
            if (!entry.getValue().isReserved()) {
                any = true;
                result += entry.getKey() + " - " + entry.getValue().getTitle() + "\n";
            }
        }

        if (!any) {
            result += "No available items at the moment.\n";
        }

        return result;
    }


    // Members + their reservations
    public String listMembersWithReservations() {

        if (members.isEmpty()) {
            return "No members registered yet.";
        }

        String result = "";

        for (Member m : members.values()) {

            result += "Member: " + m.getName() + "\n";
            result += "Membership ID: " + m.getMembershipNo() + "\n";
            result += "Finance Account: " + m.getFinanceAccountNo() + "\n";
            result += "Reserved Items:\n";

            boolean hasReserved = false;

            for (Reservation r : reservations) {
                if (r.getMember().equals(m)) {
                    hasReserved = true;
                    result += "   - " + r.getItem().getCallNo()
                            + " : " + r.getItem().getTitle() + "\n";
                }
            }

            if (!hasReserved) {
                result += "   (No items reserved)\n";
            }

            result += "-----------------------------------------\n";
        }

        return result;
    }
}
