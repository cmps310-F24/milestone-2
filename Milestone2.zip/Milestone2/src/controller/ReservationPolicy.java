package controller;

import java.util.List;

import model.Item;
import model.Member;
import model.Reservation;

/**
 * Strategy interface that defines the reservation policy.
 */
public interface ReservationPolicy {

    /**
     * Checks whether the given member is allowed to reserve the given item
     * under the current policy.
     *
     * @param member       the member trying to reserve
     * @param item         the item to be reserved
     * @param reservations existing reservations in the system
     * @return a ReservationResult indicating if reservation is OK or why it is not allowed
     */
    ReservationResult canReserve(Member member, Item item, List<Reservation> reservations);
}
