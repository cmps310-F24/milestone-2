package controller;

import java.util.List;

import model.Item;
import model.Member;
import model.Reservation;

public interface ReservationPolicy {

    ReservationResult canReserve(Member member, Item item, List<Reservation> reservations);
}
