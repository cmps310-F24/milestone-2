package controller;

public interface ExternalServices {
    boolean verifyMember(String name);
    boolean transferDeposit(String financeAccountNo, double amount);
}
