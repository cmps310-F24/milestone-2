package ui;

import controller.LibrarySystem;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LibraryApp extends Application {

    private LibrarySystem librarySystem = new LibrarySystem();

    @Override
    public void start(Stage primaryStage) {

        TabPane tabPane = new TabPane();

        // Tab 1: Register member
        Tab registerTab = new Tab("Register New Member");
        registerTab.setContent(createRegisterPane());
        registerTab.setClosable(false);

        // Tab 2: Reserve item
        Tab reserveTab = new Tab("Reserve Item");
        reserveTab.setContent(createReservePane());
        reserveTab.setClosable(false);

        // Tab 3: Members and reservations
        Tab membersTab = new Tab("Members & Reservations");
        membersTab.setContent(createMembersPane());
        membersTab.setClosable(false);

        tabPane.getTabs().addAll(registerTab, reserveTab, membersTab);

        Scene scene = new Scene(tabPane, 800, 500);
        primaryStage.setTitle("Gulf Pearl University Library System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // ---------------- Register New Member tab ----------------

    private VBox createRegisterPane() {
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();

        Button registerButton = new Button("Register Member");

        TextArea logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setWrapText(true);

        registerButton.setOnAction(e -> {
            String name = nameField.getText().trim();
            String address = addressField.getText().trim();

            if (name.isEmpty() || address.isEmpty()) {
                logArea.setText("Please fill all fields before submitting the application.");
                showAlert(
                        AlertType.WARNING,
                        "Missing Data",
                        "Name or Address is empty",
                        "Please fill both Name and Address before registering a new member."
                );
                return;
            }

            String result = librarySystem.registerNewMember(name, address);
            logArea.setText(result);

            if (result.startsWith("Membership created successfully")) {
                showAlert(
                        AlertType.INFORMATION,
                        "Member Registered",
                        "Registration completed",
                        "The member has been registered.\n\n" +
                        "Check the output for the membership and finance account numbers."
                );
                nameField.clear();
                addressField.clear();

            } else if (result.contains("Application rejected")) {
                showAlert(
                        AlertType.ERROR,
                        "Registration Rejected",
                        "University verification failed",
                        "The university system did not approve this application."
                );

            } else if (result.contains("Payment failed")) {
                showAlert(
                        AlertType.ERROR,
                        "Registration Failed",
                        "Finance transfer failed",
                        "The deposit could not be transferred. Please contact the system administrator."
                );

            } else {
                showAlert(
                        AlertType.WARNING,
                        "Registration Result",
                        "Registration did not complete successfully",
                        "Please review the output for more details."
                );
            }
        });

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        form.add(nameLabel, 0, 0);
        form.add(nameField, 1, 0);
        form.add(addressLabel, 0, 1);
        form.add(addressField, 1, 1);
        form.add(registerButton, 1, 2);

        VBox root = new VBox(10, form, new Label("Log / Output:"), logArea);
        root.setPadding(new Insets(15));
        return root;
    }

    // ---------------- Reserve Item tab ----------------

    private VBox createReservePane() {
        Label memberLabel = new Label("Membership No:");
        TextField memberField = new TextField();

        Label callLabel = new Label("Item Call No:");
        TextField callField = new TextField();

        Button reserveButton = new Button("Reserve Item");

        TextArea logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setWrapText(true);

        Label itemsLabel = new Label("Available Items (Call No - Title):");
        TextArea itemsArea = new TextArea();
        itemsArea.setEditable(false);
        itemsArea.setWrapText(true);

        itemsArea.setText(librarySystem.listAvailableItems());
        updateReserveButtonState(reserveButton, itemsArea.getText());

        Button refreshItemsButton = new Button("Refresh Available Items");
        refreshItemsButton.setOnAction(e -> {
            itemsArea.setText(librarySystem.listAvailableItems());
            updateReserveButtonState(reserveButton, itemsArea.getText());
        });

        reserveButton.setOnAction(e -> {
            String memberNo = memberField.getText().trim();
            String callNo = callField.getText().trim();

            if (memberNo.isEmpty() || callNo.isEmpty()) {
                logArea.setText("Please enter both membership number and item call number.");
                showAlert(
                        AlertType.WARNING,
                        "Missing Data",
                        "Membership No or Item Call No is missing",
                        "Please provide both values before trying to reserve an item."
                );
                return;
            }

            String result = librarySystem.reserveItem(memberNo, callNo);
            logArea.setText(result);

            if (result.startsWith("Reservation successful")) {
                showAlert(
                        AlertType.INFORMATION,
                        "Reservation Successful",
                        "Item reserved",
                        "The item has been successfully reserved for the member."
                );
                callField.clear();

            } else if (result.contains("Member account is not active or does not exist")) {
                showAlert(
                        AlertType.ERROR,
                        "Reservation Failed",
                        "Invalid member",
                        "The provided membership number does not exist or is not active."
                );

            } else if (result.contains("Item does not exist in the system")) {
                showAlert(
                        AlertType.ERROR,
                        "Reservation Failed",
                        "Invalid item",
                        "The provided item call number does not exist in the library catalogue."
                );

            } else if (result.contains("Member has reached the maximum number of reservations")) {
                showAlert(
                        AlertType.WARNING,
                        "Reservation Limit Reached",
                        "Maximum reservations exceeded",
                        "This member has already reached the maximum number of allowed reservations."
                );

            } else if (result.contains("The item is already reserved by another member")) {
                showAlert(
                        AlertType.WARNING,
                        "Reservation Not Allowed",
                        "Item already reserved",
                        "This item is already reserved by another member."
                );

            } else {
                showAlert(
                        AlertType.WARNING,
                        "Reservation Result",
                        "Reservation did not complete successfully",
                        "Please review the output for more details."
                );
            }

            itemsArea.setText(librarySystem.listAvailableItems());
            updateReserveButtonState(reserveButton, itemsArea.getText());
        });

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        form.add(memberLabel, 0, 0);
        form.add(memberField, 1, 0);
        form.add(callLabel, 0, 1);
        form.add(callField, 1, 1);
        form.add(reserveButton, 1, 2);

        VBox root = new VBox(
                10,
                form,
                new Label("Log / Output:"),
                logArea,
                itemsLabel,
                itemsArea,
                refreshItemsButton
        );
        root.setPadding(new Insets(15));
        return root;
    }

    // ---------------- Members & Reservations tab ----------------

    private VBox createMembersPane() {
        TextArea membersArea = new TextArea();
        membersArea.setEditable(false);
        membersArea.setWrapText(true);

        membersArea.setText(librarySystem.listMembersWithReservations());

        Button refreshButton = new Button("Refresh Member List");
        refreshButton.setOnAction(e -> {
            membersArea.setText(librarySystem.listMembersWithReservations());
        });

        VBox root = new VBox(
                10,
                new Label("Registered Members & Their Reservations:"),
                membersArea,
                refreshButton
        );
        root.setPadding(new Insets(15));
        return root;
    }

    // ---------------- Helpers ----------------

    private void showAlert(AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void updateReserveButtonState(Button reserveButton, String availableItemsText) {
        boolean noItems =
                availableItemsText == null
                        || availableItemsText.toLowerCase().contains("no available items");
        reserveButton.setDisable(noItems);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
