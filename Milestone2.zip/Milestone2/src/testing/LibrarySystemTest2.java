package testing;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controller.LibrarySystem;
import model.Item;
import model.Member;
import model.Reservation;

class LibrarySystemTest2 {

    private LibrarySystem librarySystem;

    @BeforeEach
    void setUp() {
        librarySystem = new LibrarySystem();
    }

    // --------------------------------------------------------------------
    // Test: registerNewMember (Functional + Performance NFR)
    // --------------------------------------------------------------------
    @Test
    void testRegisterNewMember() {

        // functional: normal registration
        String result = librarySystem.registerNewMember("Ali", "Doha");
        assertTrue(
                result.startsWith("Membership created successfully"),
                "Registration result should indicate successful membership creation."
        );

        Map<String, Member> members = librarySystem.getMembers();
        assertEquals(1, members.size(), "There should be exactly one member after registration.");
        assertTrue(members.containsKey("M1001"), "First member ID should be M1001.");

        // performance test (NFR) – many registrations within a time limit
        assertTimeoutPreemptively(
                Duration.ofMillis(1000),
                () -> {
                    for (int i = 0; i < 1000; i++) {
                        librarySystem.registerNewMember("User" + i, "Address" + i);
                    }
                },
                "Bulk registration should finish within the time limit."
        );
    }

    // --------------------------------------------------------------------
    // Test: reserveItem (Functional + Reliability NFR)
    // --------------------------------------------------------------------
    @Test
    void testReserveItem() {

        // invalid member (reliability)
        String invalid = librarySystem.reserveItem("M9999", "100001");
        assertTrue(
                invalid.contains("Member account is not active or does not exist"),
                "Reservation should fail for a non-existing or inactive member."
        );

        Item it = librarySystem.getItems().get("100001");
        assertFalse(it.isReserved(), "Item should not be reserved after a failed member check.");

        // valid reservation
        Member m = new Member("M2000", "Omar", "Doha", "Omar", "ACC-001");
        librarySystem.getMembers().put(m.getMembershipNo(), m);

        String ok = librarySystem.reserveItem("M2000", "100001");
        assertTrue(
                ok.startsWith("Reservation successful"),
                "Reservation result should indicate success."
        );

        assertTrue(
                librarySystem.getItems().get("100001").isReserved(),
                "Item 100001 should be marked as reserved after successful reservation."
        );
    }

    // --------------------------------------------------------------------
    // Test: getMembers
    // --------------------------------------------------------------------
    @Test
    void testGetMembers() {
        assertEquals(0, librarySystem.getMembers().size(), "Initially, there should be no members.");

        librarySystem.registerNewMember("Sara", "Doha");
        Map<String, Member> members = librarySystem.getMembers();

        assertEquals(1, members.size(), "There should be one member after registration.");
        assertTrue(members.containsKey("M1001"), "Member M1001 should exist.");
    }

    // Test: getItems
    @Test
    void testGetItems() {
        Map<String, Item> items = librarySystem.getItems();

        // We pre-loaded 6 items in the constructor
        assertEquals(6, items.size(), "There should be exactly 6 items in the system.");

        assertTrue(items.containsKey("100001"));
        assertTrue(items.containsKey("100002"));
        assertTrue(items.containsKey("100003"));
        assertTrue(items.containsKey("100004"));
        assertTrue(items.containsKey("100005"));
        assertTrue(items.containsKey("100006"));

        Item item = items.get("100001");
        assertEquals("CMPS 310", item.getTitle());
        assertFalse(item.isReserved(), "Items should not be reserved initially.");
    }

    // --------------------------------------------------------------------
    // Test: getReservations
    // --------------------------------------------------------------------
    @Test
    void testGetReservations() {
        assertEquals(0, librarySystem.getReservations().size(), "Initially, there should be no reservations.");

        Member m = new Member("M9000", "Huda", "Doha", "Huda", "ACC-900");
        librarySystem.getMembers().put(m.getMembershipNo(), m);
        librarySystem.reserveItem("M9000", "100001");

        List<Reservation> res = librarySystem.getReservations();
        assertEquals(1, res.size(), "There should be one reservation after reserving an item.");

        assertEquals("M9000", res.get(0).getMember().getMembershipNo());
        assertEquals("100001", res.get(0).getItem().getCallNo());
    }

    // --------------------------------------------------------------------
    // Test: listAvailableItems
    // --------------------------------------------------------------------
    @Test
    void testListAvailableItems() {
        Member m = new Member("M4000", "Mariam", "Doha", "Mariam", "ACC-321");
        librarySystem.getMembers().put(m.getMembershipNo(), m);

        String before = librarySystem.listAvailableItems();
        assertTrue(
                before.contains("100001"),
                "Item 100001 should appear as available before reservation."
        );

        librarySystem.reserveItem("M4000", "100001");

        String after = librarySystem.listAvailableItems();
        assertFalse(
                after.contains("100001"),
                "Item 100001 should not appear in the available list after reservation."
        );
    }


    // Test: listMembersWithReservations
    @Test
    void testListMembersWithReservations() {

        // no members
        String empty = librarySystem.listMembersWithReservations();
        assertTrue(
                empty.toLowerCase().contains("no members"),
                "When there are no members, the report should say so."
        );

        // one member with reservation
        Member m = new Member("M5000", "Khalid", "Doha", "Khalid", "ACC-777");
        librarySystem.getMembers().put(m.getMembershipNo(), m);
        librarySystem.reserveItem("M5000", "100001");

        String report = librarySystem.listMembersWithReservations();
        assertTrue(report.contains("M5000"));
        assertTrue(report.contains("Khalid"));
        assertTrue(report.contains("100001"));
    }
}
