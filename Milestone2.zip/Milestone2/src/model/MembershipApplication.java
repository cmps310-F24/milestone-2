package model;

public class MembershipApplication {

    private String name;
    private String address;
    private String financeAccountNo;
    private String adminComments = "";
    private String status = "";

    public MembershipApplication(String name, String address, String financeAccountNo) {
        this.name = name;
        this.address = address;
        this.financeAccountNo = financeAccountNo;
    }

    // Finance account auto
    public void setFinanceAccountNo(String financeAccountNo) {
        this.financeAccountNo = financeAccountNo;
    }

    // Getters
    public String getName() { 
        return name; 
    }

    public String getAddress() { 
        return address; 
    }

    public String getFinanceAccountNo() { 
        return financeAccountNo; 
    }

    public String getAdminComments() {
        return adminComments;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setAdminComments(String comments) {
        this.adminComments = comments;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
