package model;

public class Reservation {

    private Member member;
    private Item item;

    public Reservation(Member member, Item item) {
        this.member = member;
        this.item = item;
    }

    public Member getMember() {
        return member;
    }

    public Item getItem() {
        return item;
    }
}
