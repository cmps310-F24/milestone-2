package model;

public class Member {

    private String membershipNo;
    private String name;
    private String address;
    private String universityId;
    private String financeAccountNo;
    private int totalReservedItems;
    private boolean active;

    public Member(String membershipNo,
                  String name,
                  String address,
                  String universityId,
                  String financeAccountNo) {
        this.membershipNo = membershipNo;
        this.name = name;
        this.address = address;
        this.universityId = universityId;
        this.financeAccountNo = financeAccountNo;
        this.totalReservedItems = 0;
        this.active = true;
    }

    // Getters
    public String getMembershipNo() {
        return membershipNo;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getUniversityId() {
        return universityId;
    }

    public String getFinanceAccountNo() {
        return financeAccountNo;
    }

    public int getTotalReservedItems() {
        return totalReservedItems;
    }

    public boolean isActive() {
        return active;
    }

    // Behaviours used by controller
    public void increaseReservedItems() {
        totalReservedItems++;
    }

    public void deactivate() {
        this.active = false;
    }
}
