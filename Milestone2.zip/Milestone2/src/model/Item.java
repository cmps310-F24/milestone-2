package model;

public class Item {

    private String callNo;
    private String title;
    private int year;
    private boolean reserved;

    public Item(String callNo, String title, int year) {
        this.callNo = callNo;
        this.title = title;
        this.year = year;
        this.reserved = false;
    }

    // Getters
    public String getCallNo() {
        return callNo;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public boolean isReserved() {
        return reserved;
    }

    // Used when reservation succeeds
    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }
}
