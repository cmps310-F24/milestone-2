package external;

public class UniversitySystemStub {

    /**
     * Simulates verifying if the applicant is a registered student or staff.
     * 
     * Rule:
     *  - If the name is not empty -> verified = true
     *  - If empty -> false
     */
    public boolean verifyMember(String name) {
        return name != null && !name.trim().isEmpty();
    }
}
