package external;

public class UniversitySystemStub {

    public boolean verifyMember(String name) {
        return name != null && !name.trim().isEmpty();
    }
}
