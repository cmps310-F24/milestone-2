package external;

public class FinanceSysStub {

    /**
     * Simulates transferring QR 1500 from the applicant's Finance Account.
     * 
     * Rule:
     *  - If financeAccountNo starts with "F" -> transfer success
     *  - Otherwise -> fail (used for alternative flow 9a)
     */
    public boolean transferDeposit(String financeAccountNo, double amount) {
        if (financeAccountNo == null) return false;
        return financeAccountNo.startsWith("F");
    }
}
