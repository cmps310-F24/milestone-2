package external;

public class FinanceSysStub {

    public boolean transferDeposit(String financeAccountNo, double amount) {
        if (financeAccountNo == null) return false;
        return financeAccountNo.startsWith("F");
    }
}
